# encoding:utf-8
#
# Gramps - a GTK+/GNOME based genealogy program
#
# Copyright (C) 2026 Rodion Karpov
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along
# with this program; if not, see <https://www.gnu.org/licenses/>.

from gramps.gen.plug import Gramplet
from gramps.gen.display.name import displayer as name_displayer
from gramps.gen.const import GRAMPS_LOCALE as glocale

_ = glocale.translation.sgettext

_TOP_N = 10
_BAR_WIDTH = 20


class CompletenessGramplet(Gramplet):
    """Gramplet showing data completeness statistics for the family tree."""

    def init(self):
        self.set_use_markup(True)
        self.set_text(_("No Family Tree loaded."))

    def db_changed(self):
        self.connect(self.dbstate.db, "person-add", self.update)
        self.connect(self.dbstate.db, "person-update", self.update)
        self.connect(self.dbstate.db, "person-delete", self.update)
        self.connect(self.dbstate.db, "person-rebuild", self.update)

    def main(self):
        self.set_text(_("Processing...") + "\n")
        yield True

        db = self.dbstate.db
        handles = db.get_person_handles()
        total = len(handles)

        if total == 0:
            self.set_text(_("No people in database."))
            yield False
            return

        counts = {"birth_date": 0, "death_date": 0, "birth_place": 0, "photo": 0}
        person_scores = []

        for handle in handles:
            yield True
            person = db.get_person_from_handle(handle)
            missing = 0

            birth_ref = person.get_birth_ref()
            if birth_ref:
                birth_ev = db.get_event_from_handle(birth_ref.ref)
                if birth_ev.get_date_object().is_empty():
                    counts["birth_date"] += 1
                    missing += 1
                if not birth_ev.get_place_handle():
                    counts["birth_place"] += 1
                    missing += 1
            else:
                counts["birth_date"] += 1
                counts["birth_place"] += 1
                missing += 2

            death_ref = person.get_death_ref()
            if death_ref:
                death_ev = db.get_event_from_handle(death_ref.ref)
                if death_ev.get_date_object().is_empty():
                    counts["death_date"] += 1
                    missing += 1
            else:
                counts["death_date"] += 1
                missing += 1

            if not person.get_media_list():
                counts["photo"] += 1
                missing += 1

            name = name_displayer.display(person)
            person_scores.append((missing, name or "Без имени", handle))

        person_scores.sort(reverse=True)

        self.set_text("")
        self.render_text("<b>Полнота базы данных</b>\n\n")
        self.append_text("Всего персон: %d\n\n" % total)

        self.render_text("<b>Отсутствующие данные:</b>\n")
        fields = [
            ("Дата рождения",  counts["birth_date"]),
            ("Дата смерти",    counts["death_date"]),
            ("Место рождения", counts["birth_place"]),
            ("Фото",           counts["photo"]),
        ]
        for label, count in fields:
            pct = 100 * count // total
            bar = "█" * (pct * _BAR_WIDTH // 100)
            self.append_text("  %-17s %3d%%  %s\n" % (label + ":", pct, bar))

        self.append_text("\n")
        self.render_text("<b>Топ-%d неполных персон:</b>\n" % _TOP_N)
        for rank, (missing, name, handle) in enumerate(person_scores[:_TOP_N], 1):
            filled = 4 - missing
            self.append_text("  %d. " % rank)
            self.link(name, "Person", handle)
            self.append_text(" (%d/4)\n" % filled)

        self.append_text("", scroll_to="begin")
        yield False
